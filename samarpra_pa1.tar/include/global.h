#ifndef GLOBAL_H_
#define GLOBAL_H_

#define HOSTNAME_LEN 128
#define PATH_LEN 256
#define CMD_SIZE 1024
#define BACKLOG 10
#define MSG_SIZE 256
#define BUFFER_SIZE 256
#define STDIN 0
#define TRUE 1
#define FALSE 0


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include<string.h>
#include<stdbool.h>
#include<arpa/inet.h>
#include<string>
#include <iostream>


#endif

