#include<bits/stdc++.h>
using namespace std;
int ip_command(std::string command);
int server_handle_send(std::string commandDummy);
bool checkForLower(std::string command);