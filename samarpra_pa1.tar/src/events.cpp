#include "../include/global.h"
#include "../include/logger.h"
#include "../include/text.h"


int ip_command(std::string command) {
    char myHostName[1024], buffer[256];
    gethostname(myHostName, sizeof(myHostName)-1);
    host_name = myHostName;

    size_t bufLen = 256;

    // now attempt to connect to this google's server address
    int udp_sock_fd = socket(AF_INET,SOCK_DGRAM,0);
    const char *kGoogleDnsIp = "8.8.8.8";
    uint16_t kDnsPort = 53;
    struct sockaddr_in googleServInfo;
    memset(&googleServInfo, 0, sizeof(googleServInfo));
    googleServInfo.sin_family = AF_INET;
    googleServInfo.sin_addr.s_addr = inet_addr(kGoogleDnsIp);
    googleServInfo.sin_port = htons(kDnsPort);

    if(connect(udp_sock_fd, (struct sockaddr *) &googleServInfo, sizeof(googleServInfo)) != -1) {
        
    }
    else{
        cse4589_print_and_log("[%s:ERROR]\n", command.c_str());
        cse4589_print_and_log("[%s:END]\n", command.c_str());		
    }

    struct sockaddr_in name;
    socklen_t namelen = sizeof(name);
    if(getsockname(udp_sock_fd, (struct sockaddr *)&name, &namelen) != -1) {

    }
    else{
        cse4589_print_and_log("Failed to get the socket name of the host\n");
    }
    const char *myIp = inet_ntop(AF_INET, &name.sin_addr, buffer, bufLen);
    ip = myIp;
    close(udp_sock_fd);

    cse4589_print_and_log("[%s:SUCCESS]\n", command.c_str());
    cse4589_print_and_log("IP:%s\n", buffer);
    cse4589_print_and_log("[%s:END]\n", command.c_str());
    return 0;
}

bool checkForLower(std::string command) {
	int i=0;
	while(i<command.size()) {
		if(command[i] == ' ') break;
		else if(command[i]<'A' || command[i] >'Z') {
			cse4589_print_and_log("Found the lowercase letter: %c\n", command[i]);
			return true;
		}
		i++;
	}
	return false;
}


int server_handle_send(std::string cmd_dm) {

			int it =0, wrd = 0;
			int a = 5 ;
			char x ;
			char * client_ip = "";

			char * dummy = "";
			for(it=0; it < cmd_dm.size(); it++) {
				if(cmd_dm[it] == ' ') {
					if(wrd == 0) {
						wrd++;
						dummy = "";
					} else if(wrd == 1) {
						client_ip = dummy;
					dummy = "";
					wrd++;
					}
				} else {
					dummy = dummy + cmd_dm[it];
				}
			}

    return 0;
}